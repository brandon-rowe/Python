class Assign4_Q1:
    def subSets(self, sub):
        return self.reSub([], sorted(sub))

    def reSub(self, current, sub):
        if sub:
            return self.reSub(current, sub[1:]) + self.reSub(current + [sub[0]], sub[1:])
        return [current]

print(Assign4_Q1().subSets([4,5,6]))
