class Assign4_Q5():
    def __init__(self, l, w):
        self.length = l
        self.width  = w

    def _area(self):
        return self.length * self.width

newRec = Assign4_Q5(25, 15)
print(newRec._area())
