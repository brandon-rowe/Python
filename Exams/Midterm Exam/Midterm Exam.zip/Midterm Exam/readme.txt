Dr. Zhao,

I have worked for a while on the graphics problem. I cannot seem to get any graphics to work on my machine. I will endeavor to get better with this section but at the moment, I must admit defeat. I have tried several different options and referenced the book, slides, online materials and cannot get the graphics to work properly on my machine.

Sincerely,

B. Rowe