from graphics import *
def main():

     win = GraphWin('checker')
     center = Point(100,100)
     rect = Rectange(Point(30,30), Point(70,70))
#    for i in range(10):
#        for j in range(10):
#            if (i + j) % 2 == 0:
#                color = 'black'
#            else:
#                color = 'red'
#            canvas.setFill(color)
#            canvas.drawRect(_x + i * _HW, _y + j * _HW, _HW, _HW)
main()
